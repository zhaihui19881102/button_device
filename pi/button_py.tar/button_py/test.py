
from gpiozero import Button,LED
from signal import pause

led24=LED(24)
#led25=LED(25)

led24.blink()
#led25=LED(25)

pause()
