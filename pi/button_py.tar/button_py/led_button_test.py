from gpiozero import Button,LED
import time

led=LED(24)
button=Button(25)

print(led)
print(button)
print(button.is_pressed)


while(True):
	print('button_pressed is ',button.is_pressed)
	led.on()
	time.sleep(1)
	led.off()
	time.sleep(1)
